#ifndef _LCDDV_H
#define _LCDDV_H
#include "stm32f10x.h"

/*==============��������==============*/
extern uint8_t Reset_LCD[];
extern uint8_t Clear_LCD[];
extern uint8_t LCD_Display_CMD[];
extern uint8_t NORMAL[];//"NORMAL"
extern uint8_t WERROR[];//"ERROR"
extern uint8_t INSERT[];//"INSERT"




#endif

